/// <reference path="typings/angularjs/angular.d.ts" />
